﻿// CORRECTED VERSION for Supabase Edge Runtime
import { serve } from "std/server";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";

// Initialize Stripe
const stripeSecret = Deno.env.get("STRIPE_SECRET_KEY");
if (!stripeSecret) throw new Error("STRIPE_SECRET_KEY is not set");
const stripe = new Stripe(stripeSecret, {
  apiVersion: "2025-02-24.acacia",
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // 1. Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  // 2. Handle Stripe endpoint verification
  if (req.method === "GET" || req.method === "HEAD") {
    return new Response("✅ Stripe webhook endpoint is live.", {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "text/plain" },
    });
  }

  // 3. Process POST webhook
  try {
    const signature = req.headers.get("stripe-signature");
    const body = await req.text();

    // Guard: Empty test payload
    if (!body || body.length === 0) {
      console.log("[INFO] Empty test payload received.");
      return new Response(JSON.stringify({ received: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Guard: Missing signature or secret
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    if (!signature || !webhookSecret) {
      console.error("[ERROR] Missing signature or STRIPE_WEBHOOK_SECRET.");
      return new Response("Missing signature or secret", { status: 400, headers: corsHeaders });
    }

    // Verify event
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    console.log(`[INFO] Webhook verified: ${event.type} (ID: ${event.id})`);

    // 4. Handle checkout.session.completed
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const userId = session.metadata?.user_id;
      const tokensToMint = parseInt(session.metadata?.tokens_to_mint || "5", 10);

      console.log(`[INFO] Processing session ${session.id} for user ${userId}, minting ${tokensToMint} tokens.`);

      if (!userId) {
        throw new Error("Missing user_id in session metadata.");
      }

      // Initialize Supabase Admin Client
      const supabaseUrl = Deno.env.get("SUPABASE_URL");
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
      if (!supabaseUrl || !supabaseKey) {
        throw new Error("Missing Supabase URL or Service Role Key.");
      }
      const supabase = createClient(supabaseUrl, supabaseKey, {
        auth: { persistSession: false },
      });

      // Use the RPC function
      const { error: rpcError } = await supabase.rpc("increment_token_balance", {
        user_id: userId,
        amount: tokensToMint,
      });

      if (rpcError) {
        console.error("[ERROR] RPC call failed:", rpcError);
        throw rpcError;
      }

      console.log(`[SUCCESS] Minted ${tokensToMint} tokens for user ${userId}.`);
    }

    // 5. Return success
    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[ERROR] Webhook processing failed:", err.message);
    return new Response(`Webhook Error: ${err.message}`, {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});